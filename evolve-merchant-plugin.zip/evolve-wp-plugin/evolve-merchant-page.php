<?php
/**
 * Plugin Name: Evolve Merchant Services - Full Site
 * Description: Complete Evolve Merchant Services website as a WordPress page
 * Version: 1.0
 * Author: Evolve Merchant Services
 */

// Register shortcode
add_shortcode('evolve_full_site', 'evolve_render_full_site');

function evolve_render_full_site() {
    $html_file = plugin_dir_path(__FILE__) . 'index.html';
    
    if (file_exists($html_file)) {
        return file_get_contents($html_file);
    }
    
    return '<p>Error: Website file not found.</p>';
}

// Create page on activation
register_activation_hook(__FILE__, 'evolve_create_page');

function evolve_create_page() {
    $page_check = get_page_by_title('Evolve Merchant Services');
    
    if (!isset($page_check->ID)) {
        $page = array(
            'post_title'    => 'Evolve Merchant Services',
            'post_content'  => '[evolve_full_site]',
            'post_status'   => 'publish',
            'post_type'     => 'page',
            'post_author'   => 1
        );
        
        wp_insert_post($page);
    }
}
